<?php
  session_start();
  include "dbconnection.php";
  


?>
<!DOCTYPE html>
<html>
<head>
  <title>User Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  
 
  
  
</head>
<body style=" text-align: center;margin-top: 10px;">
  <div class="container">
<h1 class="font-weight-bolder">Registration Form</h1>
<form class="form-horizontal" action="core.php" method="POST">
    <div class="form-group">
      <label class="control-label col-sm-4" for="username">Username</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" id="username" placeholder="Enter username" name="username">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="password">Password</label>
      <div class="col-sm-4">          
        <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="cpassword">Confirm Password</label>
      <div class="col-sm-4">          
        <input type="password" class="form-control" id="cpassword" placeholder="Confirm password" name="cpassword">
      </div>
    </div>
    <div class="form-group">
            <label class="control-label col-sm-4" for="avatar">Avatar</label>
            <div class="col-sm-4">
              <input type="file" id="avatar" class="form-control" placeholder="Choose Pic" name="avatar">
              
            </div>
          </div>
    
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-4" style="margin-left: 500px;">
        <button type="submit" class="btn btn-default" name="adduser">Subscribe</button>
      </div>
      <div class="col-sm-offset-2 col-sm-4" style="margin-left: -500px;">
        <button type="submit" class="btn btn-default">Reset Form</button>
      </div>
    </div>
  </form>
</div>
</body>
</html>



<?php unset($_SESSION['msg']); ?>


