<?php
session_start();
include "dbconnection.php";

$query = $db->query("SELECT * FROM messenger ORDER BY id DESC");
$messengers = $query->fetchAll(PDO::FETCH_ASSOC);

var_dump($messengers);
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Login</title>
	<meta charset="utf-8">
  <link rel="stylesheet" href="example1/colorbox.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

  <script src="jquery.colorbox.js"></script>

  <link rel="stylesheet" href="colorbox.css" />
  <link rel="stylesheet" href="helper.css" />
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
  <script src="jquery.colorbox.js"></script>
  <script>
    $(document).ready(function(){
        //Examples of how to assign the Colorbox event to elements
        $(".group1").colorbox({rel:'group1'});
        $(".group2").colorbox({rel:'group2', transition:"fade"});
        $(".group3").colorbox({rel:'group3', transition:"none", width:"75%", height:"75%"});
        $(".group4").colorbox({rel:'group4', slideshow:true});
        $(".ajax").colorbox();
        $(".youtube").colorbox({iframe:true, innerWidth:640, innerHeight:390});
        $(".vimeo").colorbox({iframe:true, innerWidth:500, innerHeight:409});
        $(".iframe").colorbox({iframe:true, width:"80%", height:"80%"});
        $(".inline").colorbox({inline:true, width:"50%"});
        $(".callbacks").colorbox({
          onOpen:function(){ alert('onOpen: colorbox is about to open'); },
          onLoad:function(){ alert('onLoad: colorbox has started to load the targeted content'); },
          onComplete:function(){ alert('onComplete: colorbox has displayed the loaded content'); },
          onCleanup:function(){ alert('onCleanup: colorbox has begun the close process'); },
          onClosed:function(){ alert('onClosed: colorbox has completely closed'); }
        });

/*
        $('.non-retina').colorbox({rel:'group5', transition:'none'})
        $('.retina').colorbox({rel:'group5', transition:'none', retinaImage:true, retinaUrl:true});
        */
        //Example of preserving a JavaScript event for inline calls.
        $("#click").click(function(){
          $('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
          return false;
        });
      });
    </script>

    <script>
     $(document).ready(function(){
				//Examples of how to assign the Colorbox event to elements

				$(".iframe").colorbox({iframe:true, width:"45%", height:"39%"});

				//Example of preserving a JavaScript event for inline calls.
				// $("#click").click(function(){ 
				// 	$('#click').css({"background-color":"#f00", "color":"#fff", "cursor":"inherit"}).text("Open this window again and this message will still be here.");
				// 	return false;
				// });
			});
		</script>

  </head>
  <body style="background-color: grey; text-align: center;margin-top: 50px;">


   <?php if(isset($_SESSION['msg'])): ?>
    <div class="alert alert-success">
     <strong>Success!</strong> <?= $_SESSION['msg']; ?>
   </div>
 <?php endif; ?>

 <?php if(isset($_GET['error']) AND $_GET['error'] == "usernameEmpty"): ?>
  <div class="alert alert-danger">
    <strong>Error!</strong> Username Cannot Be Empty
  </div>
  <?php elseif(isset($_GET['error']) AND $_GET['error'] == "usernameDup"): ?>
    <div class="alert alert-danger">
      <strong>Error!</strong> Username Exist Already
    </div>

    <?php elseif(isset($_GET['error']) AND $_GET['error'] == "usernameEmp"): ?>
      <div class="alert alert-danger">
        <strong>Error!</strong> Username,Password cannot be empty
      </div>

      <?php elseif (isset($_GET['error']) AND $_GET['error'] == "password"):?>
       <div class="alert alert-danger">
         <strong>Error!</strong> Confirm Password don't match
       </div>

     <?php elseif (isset($_GET['error']) AND $_GET['error'] == "login"):?>
       <div class="alert alert-danger">
         <strong>Error!</strong> wrong credentials
       </div>
     <?php endif; ?>


     <h1 style="font-weight: bold;">Mini-Chat</h1>
     <form class="form-horizontal" action="core.php" method="POST" style="border: 3px solid black;width: 27%;
     margin-left: 36%;">
     <div class="form-group">
      <label class="control-label col-sm-4" for="username">Username</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" id="username" placeholder="Enter username" name="username">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-4" for="password">Password</label>
      <div class="col-sm-4">          
        <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
      </div>
    </div>
    
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-4" style="margin-left: 19% !important;
      margin-right: -80px !important;">
      <button type="submit" class="btn btn-default" name="login">Login</button>
    </div>
    <div class="col-sm-offset-2 col-sm-4" >
      <a class="inline btn btn-default"  href="#inline_content" style="text-decoration: none;color:black">Register</a>
    </div>
    <?php if(isset($_SESSION['msg'])): ?>
      <div class="alert-success">
        <strong>success!</strong><?=$_SESSION['msg'];?>
      </div>
    <?php endif; ?>
  </div>
</form>




<!-- This contains the hidden content for inline calls -->
<div style='display:none'>
  <div id='inline_content' style='padding:10px; background:#fff;'>
    <h1>Registration Form</h1>
    <form class="form-horizontal" action="core.php" method="POST">
      <div class="form-group">
        <label class="control-label col-sm-4" for="username">Username</label>
        <div class="col-sm-4">
          <input type="text" class="form-control" id="username" placeholder="Enter username" name="username">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-4" for="password">Password</label>
        <div class="col-sm-4">          
          <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-4" for="cpassword">Confirm Password</label>
        <div class="col-sm-4">          
          <input type="password" class="form-control" id="cpassword" placeholder="Confirm password" name="cpassword">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-4" for="avatar">Avatar</label>
        <div class="col-sm-4">
          <input type="file" id="avatar" class="form-control" placeholder="Choose Pic" name="avatar">

        </div>
      </div>

      <div class="form-group">        
        <div class="col-sm-offset-2 col-sm-4" style="margin-left: 500px;">
          <button type="submit" class="btn btn-default" name="adduser">Subscribe</button>
        </div>
        <div class="col-sm-offset-2 col-sm-4" style="margin-left: -500px;">
          <button type="submit" class="btn btn-default">Reset Form</button>
        </div>
      </div>
    </form>

    <!-- check to see if there an error from the core -->
    <?php if(isset($_GET['error']) AND $_GET['error'] == "username"): ?>
      <div class="alert alert-danger">
        <strong>Error!</strong> Username Exist Already
      </div>
      <?php elseif (isset($_GET['error']) AND $_GET['error'] == "password"):?>
        <div class="alert alert-danger">
          <strong>Error!</strong> confirm Password don't match
        </div>
        <?php elseif (isset($_GET['imgError'])):?>
          <div class="alert alert-danger">
            <strong>Error!</strong> <?php echo $_GET['imgError'] ?>
          </div>
        <?php endif; ?>
      </div>
    </div>
  </div>

<form class="form-horizontal" action="core.php" method="POST" style="border: 2px solid black;width: 20%;margin-left: 15%;margin-top: 2%;">
  <h2>Send Message</h2>

  <textarea name="comment" cols="24" rows="5"></textarea>
  <br>

  <input type="submit" name="send" value="send">

</form>

<form class="form-horizontal" action="" method="POST" style="border: 2px solid black;width: 30%;display: inline-block;height: 500px;">
  <h2>Message form Database</h2>
  
 <?php foreach ($messengers as $key => $value): ?>
   <div>
   <img src="https://cdn3.iconfinder.com/data/icons/german-shepherd-dog-face/800/cool_dog-512.png" width="50" height="50"><span style="font-weight: bold"><?= $value['username']  ?></span>&nbsp;&nbsp;<span><?= $value['comment']  ?></span>  
   <hr>
 </div>
 <?php endforeach ?>
 


</form>

</body>
</html>
<?php unset($_SESSION['msg']); ?>