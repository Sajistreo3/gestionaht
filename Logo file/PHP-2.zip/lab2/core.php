<?php
session_start();

include "dbconnection.php";
/*Register page*/

if(isset($_POST['adduser'])){


	if(empty($_POST['username'])){
		header("location: index.php?error=usernameEmpty");
	}
	else{
		$query = $db->prepare("SELECT username FROM thesauras WHERE username = :username");
		$query->execute(array("username" => $_POST['username']));
		$result = $query->fetch(PDO::FETCH_ASSOC);

		if($result){
			header("location: index.php?error=usernameDup");
		}
		else{

			if(!empty($_POST['password']) && ($_POST['password'] != $_POST['cpassword'])){
				header("location: index.php?error=password");
			}
			else{

				$query = $db->prepare("INSERT INTO thesauras VALUES (DEFAULT, :username, :password, :avatar, :status)");
				
				$temp = $query->execute(array(
					"username" 	=> $_POST['username'],
					"password" 	=> $_POST['password'],
					"status"	=> 0,
					"avatar" 	=> $_POST['avatar']

				));
				$_SESSION['msg'] = $_POST['username']. " was added successfully!";
				header("location: index.php");
			}
		}
	}
} 

/*login page*/
elseif(isset($_POST['login'])){
	$username=$_POST['username'];
	$password=$_POST['password'];
	echo "welcome back".$username;

	if(empty($username)||empty($password))
		header("location: index.php?error=usernameEmp");
	else{
		$query = $db->query("SELECT * FROM thesauras WHERE username = '$username' and password = '$password'");
		$result = $query->fetch(PDO::FETCH_ASSOC);

		if($result){
			$_SESSION['msg'] = "welcome back $username" ;
		 	header("location: index.php?success");
		}else
		 	header("location: index.php?error=login");
	}
}
elseif(isset($_POST['send'])){
	$comment=$_POST['comment'];
	$query = $db->prepare("INSERT INTO message VALUES (DEFAULT, :username, :comment, :avatar)");
	$query->execute(array(
		"username" => $_SESSION['username'],
		"avatar" => $_POST['avatar'],
		"comment" => $_POST['comment']
	));
	$_SESSION['msg'] =  $_SESSION['username']."text added successfully" ;
	header("location: index.php");
}

else{
	die("go to hell");
}



?>