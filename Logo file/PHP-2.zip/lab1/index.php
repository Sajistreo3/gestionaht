<?php session_start(); ?>
<?php include 'header.php'; ?>
 
 <div class="container-fluid">
		<div class="container">
			<h2 class="text-center" id="title">Mushu's Impossible Guessing Game</h2>
 			<hr>
			<div class="row">
				<div class="col-md-5">
 					<form role="form" method="post" action="core.php" enctype="multipart/form-data">
 					

 						  <?php if(isset($_GET['error']) AND $_GET['error'] == "password"):?>
				          <div class="alert alert-danger">
				            <strong>Error!</strong> confirm Password don't match
				          </div>
				          
				           <?php elseif(isset($_GET['success']) AND $_GET['success'] == "password"):  ?>
				           <div class="alert alert-success" >
				            <strong>successful!</strong> successful registration
				            </div>
				            <?php endif ; ?>
						<fieldset>
							<p class="text-uppercase"><b>SIGN UP</b></p>
 							<div class="form-group">
								<input type="text" name="username" id="username" class="form-control input-lg" placeholder="username" required>
							</div>

							<div class="form-group">
								<input type="email" name="email" id="email" class="form-control input-lg" placeholder="Email Address" required >
							</div>
							<div class="form-group">
								<input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password" required>
							</div>
								<div class="form-group">
								<input type="password" name="cpassword" id="cpassword" class="form-control input-lg" placeholder="Confirm Password" required>
							</div>
 							<div>
 								<input type="submit" class="btn btn-lg btn-primary" value="Register" name="Register">
 							</div>
						</fieldset>
					</form>
				</div>

				<div class="col-md-5 offset-md-2">
 				 	<form role="form" method="post" action="core.php">
 				 		<?php if (isset($_GET['error']) AND $_GET['error'] == "incorrect credentials"):?>
				          <div class="alert alert-danger">
				            <strong>Error!</strong> go to hell
				          </div>
				          
				          <?php endif; ?>
						<fieldset>
							<p class="text-uppercase"><b>Login using your account</b></p>

							<div class="form-group">
								<input type="text" name="username" id="username" class="form-control input-lg" placeholder="username" required>
							</div>
							<div class="form-group">
								<input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password" required>
							</div>
							<div>
								<input type="submit" class="btn btn-md btn-success" value="Sign In" name="SignIn">
							
								
							</div>

 						</fieldset>
					</form>
				</div>
			</div>
			<?php include 'footer.php'; ?>