<!DOCTYPE html>
<html lang="en">

	<head>
		<title>Guessing Game - Hezing College</title>

		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
		<script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>

		<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
		<style type="text/css">
			body {background-color:#eee;}
			.container-fluid {padding:50px;}
			.container{background-color:white;padding:50px;}
			#title{font-family: 'Lobster', cursive;}
		</style>
	</head>