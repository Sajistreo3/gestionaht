<?php
session_start();

if(!isset($_SESSION['user']))
	header("location: index.php");

if(!isset($_SESSION['count'])){
	$_SESSION['won']=0;
	$_SESSION['lost']=0;
	$_SESSION['count']=0;
	$_SESSION['gameplay']=$_SESSION['won'] + $_SESSION['lost'];
	returnWord();

}

if(isset($_POST['submit'])){

	if(strtolower($_SESSION['currentword']) == strtolower($_POST['word'])){

		$_SESSION['won']++;
		$_SESSION['count']=0;
		returnWord();
	}elseif($_SESSION['count']<5){
		$_SESSION['count']++;
	}else{
		$_SESSION['lost']++;
		$_SESSION['count']=0;
		returnWord();
	}
}

function returnWord(){
	$file=fopen("words.txt","r");
	$word=array();
	while(!feof($file))
		$word[]=trim(fgets($file));

	fclose($file);
	$r=rand(0,count($word)-1);
	$_SESSION['currentword'] = $word[$r];
	echo "<script>console.log('Hint: ".$word[$r]."')</script>";
}

// if(isset($_POST['logout'])){
// 	unset($_SESSION['wonu']);
// 	unset($_SESSION['count']);
// 	unset($_SESSION['lost']);
// 	unset($_SESSION['gameplay']);

// }
 ?>


<?php include 'header.php'; ?>


<div class="container" style="    margin-top: 83px;">

			<h2 class="text-center" id="title">
				Mushu's Impossible Guessing Game <br>
				<small>Welcome back  <?php  echo $_SESSION['user']['username']?>, have fun!</small>

			</h2>

 			<hr>
			<div class="row">
				<div class="col-md-12">

					<form role="form" method="POST">
						<fieldset>
							<p class="text-uppercase"><b>Try to guess the following word: <big class="text-danger"><em>
							 <?php 
							 $originalWord = $_SESSION['currentword'];
							 $shuffledWord = $_SESSION['currentword'];
							 echo str_shuffle($shuffledWord); ?>



							 
							</em></big><?php echo($originalWord); ?></b></p>

							<div class="input-group mb-3">
							  <input type="text" class="form-control" placeholder="Guess Here" aria-describedby="basic-addon2" name="word">

							  <div class="input-group-append">
							    <input type="submit" class="btn btn-info" name="submit" value="submit" >


							</div>
						</fieldset>



					</form>
					<form role="form" method="post" action="core.php"><div style="float: right;"><input type="submit" class="btn btn-md btn-danger" value="logout" name="logout"></div></form>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<h1 class="text-center">Game Stats</h1>
					<hr>
				</div>
				<div class="col-md-3 text-center text-primary text-uppercase">
					<div class="card">
						<strong>Game Played</strong>
						<h1><?php echo $_SESSION['won'] + $_SESSION['lost']; ?></h1>
					</div>
				</div>
				<div class="col-md-3 text-center text-success text-uppercase">
					<div class="card">
						<strong>Game Won</strong>
						<h1><?php echo $_SESSION['won'] ; ?></h1>
					</div>
				</div>
				<div class="col-md-3 text-center text-danger text-uppercase">
					<div class="card">
						<strong>Game Lost</strong>
						<h1><?php echo $_SESSION['lost']; ?></h1>
					</div>
				</div>
				<div class="col-md-3 text-center text-info text-uppercase">
					<div class="card">
						<strong>Current Tries</strong>
						<h1><?php echo  $_SESSION['count'] ?></h1>
					</div>
				</div>
			</div>
			<hr>
		</div>

		</div>
		<?php include 'footer.php'; ?>