<p class="text-center">
			<small id="passwordHelpInline" class="text-muted"> George Boursiquot:<a href="https://herzingmontreal.ca" target="_blank"> Herzing College Montreal </a>
		</p>
	</div>
	</body>


</html>