<?php 
session_start();
//login
if (isset($_POST["SignIn"])) {

	$file=fopen("database.txt","r");
	$userDB=array();

	while(!feof($file)){
		$obj = json_decode(trim(fgets($file)),1);
		$userDB[$obj['username']]=$obj;
	}

	fclose($file);
// var_dump($userDB);
// var_dump($userDB[$_POST['username']]['password']);
	if(array_key_exists($_POST['username'], $userDB) AND $userDB[$_POST['username']]['password'] == $_POST['password']){
		$_SESSION['user'] = $userDB[$_POST['username']];

 		header("location: content.php");
 	}
 	else{
		header("location: index.php?error=incorrect credentials");
 	}
}




if (isset($_POST["Register"])) {
	if(!empty($_POST['username']) && array_key_exists($_POST['username'], $userDB))
		header("location: index.php.php?error=username");
	else if(!empty($_POST['password']) && ($_POST['password'] != $_POST['cpassword']))
		header("location: index.php?error=password");
	else{
	$userDB=array(
				"username" => $_POST['username'],
				"email" => $_POST['email'],
				"password" => $_POST['password'],
				"cpassword" => $_POST['cpassword']
			);
	
	
$_SESSION['user']=$_POST['username'];

	$file=fopen("database.txt","a+") or die("file not exist");
	fwrite($file,json_encode($userDB) ."\n");
	header("location: index.php?success=password");
	fclose($file);
}
}

//logout
if(isset($_POST['logout'])){
    unset($_SESSION['wonu']);
	unset($_SESSION['count']);
	unset($_SESSION['lost']);
	unset($_SESSION['gameplay']);

	$_SESSION['user'] = false;
	header("location: index.php");
}


 ?>